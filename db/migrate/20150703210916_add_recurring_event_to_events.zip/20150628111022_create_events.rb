class CreateEvents < ActiveRecord::Migration
  def change
    create_table :events do |t|
      t.string :summary
      t.string :dateTime
      t.string :timeZone
      t.string :location
      t.text :description
      t.integer :colorId

      t.timestamps null: false
    end
  end
end
