class AddImageFilepathColumnToEvents < ActiveRecord::Migration
  def change
    add_column :events, :image_filepath, :string
  end
end
