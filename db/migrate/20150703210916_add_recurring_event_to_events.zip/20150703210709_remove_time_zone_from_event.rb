class RemoveTimeZoneFromEvent < ActiveRecord::Migration
  def change
    remove_column :events, :timeZone, :string
  end
end
