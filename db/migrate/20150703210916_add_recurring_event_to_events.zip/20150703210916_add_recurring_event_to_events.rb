class AddRecurringEventToEvents < ActiveRecord::Migration
  def change
    add_column :events, :recurring_event, :string
  end
end
