class RemoveRecurringEventFromEvents < ActiveRecord::Migration
  def change
    remove_column :events, :recurring_event, :string
  end
end
