class AddDateTimeToEvents < ActiveRecord::Migration
  def change
    add_column :events, :dateTime, :DateTime
  end
end
