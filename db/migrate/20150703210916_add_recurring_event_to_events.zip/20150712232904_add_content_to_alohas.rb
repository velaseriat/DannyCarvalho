class AddContentToAlohas < ActiveRecord::Migration
  def change
    add_column :alohas, :content, :string
  end
end
