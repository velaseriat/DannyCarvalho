class AddPaypalToAlbums < ActiveRecord::Migration
  def change
    add_column :albums, :paypal, :string
  end
end
