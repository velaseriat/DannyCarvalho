class AddColumnsToProducts < ActiveRecord::Migration
  def change
    add_column :products, :paypal, :string
    add_column :products, :album_id, :string
  end
end
