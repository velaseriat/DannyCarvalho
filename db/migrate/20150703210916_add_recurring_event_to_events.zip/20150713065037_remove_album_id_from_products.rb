class RemoveAlbumIdFromProducts < ActiveRecord::Migration
  def change
    remove_column :products, :album_id, :string
  end
end
