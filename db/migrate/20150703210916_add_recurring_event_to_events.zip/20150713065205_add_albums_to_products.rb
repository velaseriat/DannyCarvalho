class AddAlbumsToProducts < ActiveRecord::Migration
  def change
    add_column :products, :album_id, :integer
  end
end
