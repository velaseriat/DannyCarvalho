class CreateIgrams < ActiveRecord::Migration
  def change
    create_table :igrams do |t|
      t.string :image_path
      t.string :link
      t.text :text
      t.datetime :dateTime
      t.string :url

      t.timestamps null: false
    end
  end
end
