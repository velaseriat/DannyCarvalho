class RemoveUrlFromIgrams < ActiveRecord::Migration
  def change
    remove_column :igrams, :Url, :string
  end
end
