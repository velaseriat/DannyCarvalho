class CreateAvantis < ActiveRecord::Migration
  def change
    create_table :avantis do |t|
      t.text :hell

      t.timestamps null: false
    end
  end
end
