class RemoveDataFromProducts < ActiveRecord::Migration
  def change
    remove_column :products, :data, :string
  end
end
