class AddDataToProducts < ActiveRecord::Migration
  def change
    add_column :products, :data, :text
  end
end
