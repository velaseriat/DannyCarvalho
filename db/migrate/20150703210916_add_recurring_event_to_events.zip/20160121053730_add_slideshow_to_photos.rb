class AddSlideshowToPhotos < ActiveRecord::Migration
  def change
    add_column :photos, :slideshow, :boolean
  end
end
